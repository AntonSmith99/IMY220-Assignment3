<?php
	// See all errors and warnings
	error_reporting(E_ALL);
	ini_set('error_reporting', E_ALL);

	$mb_convert = 1024*1024;
	// Your database details might be different
	$mysqli = new mysqli("localhost", "root", "", "dbuser");
	//$id = "";
	$email = isset($_POST["loginName"]) ? $_POST["loginName"] : false;
	$pass = isset($_POST["loginPassw"]) ? $_POST["loginPassw"] : false;	
//	$pic = isset($_POST["picToUpload"]) ? $_POST["picToUpload"] : false;
	if(isset($_FILES["fileToUpload"]))
	{
		$target_dir = "gallery/";
		$imagename = basename($_FILES["fileToUpload"]["name"]);
		$target_file = $target_dir . $imagename;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		if(($imageFileType === "jpg" || $imageFileType === "jpeg") && filesize($target_file)/$mb_convert < 1)
		{
			move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
			
			$query = "SELECT user_id FROM tbusers WHERE email = '$email' AND password = '$pass'";
			$result = $mysqli->query($query);
			$record = $result->fetch_assoc();
			
			$id = $record["user_id"];
			//echo $id;
			$query = "INSERT INTO tbgallery (user_id, filename) VALUES ('$id', '$imagename');";
			$mysqli->query($query);
			/*
			$name = $_POST["regName"];
			$surname = $_POST["regSurname"];
			$email = $_POST["regEmail"];
			$date = $_POST["regBirthDate"];
			$pass = $_POST["pass1"];
			*/
			//$query = "INSERT INTO tbusers (name, surname, email, birthday, password) VALUES ('$name', '$surname', '$email', '$date', '$pass');";

			//$res = mysqli_query($mysqli, $query) == TRUE;
		}

	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>IMY 220 - Assignment 3</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css" />
	<meta charset="utf-8" />
	<meta name="author" content="Anton Smith">
	<!-- Replace Name Surname with your name and surname -->
</head>
<body>
	<div class="container">
		<?php
			if($email && $pass){
				$query = "SELECT * FROM tbusers WHERE email = '$email' AND password = '$pass'";
				$res = $mysqli->query($query);
				if($row = mysqli_fetch_array($res)){
					echo 	"<table class='table table-bordered mt-3'>
								<tr>
									<td>Name</td>
									<td>" . $row['name'] . "</td>
								<tr>
								<tr>
									<td>Surname</td>
									<td>" . $row['surname'] . "</td>
								<tr>
								<tr>
									<td>Email Address</td>
									<td>" . $row['email'] . "</td>
								<tr>
								<tr>
									<td>Birthday</td>
									<td>" . $row['birthday'] . "</td>
								<tr>
							</table>";
				
					echo 	"<form enctype='multipart/form-data' action='login.php' method='post'>
								<div class='form-group'>
									<input type='file' class='form-control' name='fileToUpload' id='fileToUpload' /><br/>
									<input type='hidden' name='loginName' id='loginName' value='" . $email . "' />
									<input type='hidden' name='loginPassw' id='loginPassw' value='" .  $pass . "'>
									<input type='submit' class='btn btn-standard' value='Upload Image' name='submit' />
								</div>
						  	</form>";


					$query = "SELECT user_id FROM tbusers WHERE email = '$email' AND password = '$pass'";
					$result = $mysqli->query($query);
					$record = $result->fetch_assoc();
			
					$id = $record["user_id"];	  	
					
					$query = "SELECT filename FROM tbgallery WHERE user_id = '$id'";
					$result = $mysqli->query($query);
					
					if ($result->num_rows > 0) {
						echo 	"<div class='card-header'>Image Gallery</div>";
						$seperator = 1;
						echo "<div class='row imageGallery'>";
						while($record = $result->fetch_assoc()){
							$theFileName = $record["filename"];
							//echo $theFileName;
							echo "<div class='col-3' style='background-image: url(gallery/" . $theFileName . ")'></div>";
							$seperator = $seperator + 1;
							if($seperator%5 == 0)
							{
								echo "</div><div class='row imageGallery'>";
							}
						}

					}

				}
				else{
					echo 	'<div class="alert alert-danger mt-3" role="alert">
	  							You are not registered on this site!
	  						</div>';
				}
			} 
			else{
				echo 	'<div class="alert alert-danger mt-3" role="alert">
	  						Could not log you in
	  					</div>';
			}
		?>
	</div>
</body>
</html>